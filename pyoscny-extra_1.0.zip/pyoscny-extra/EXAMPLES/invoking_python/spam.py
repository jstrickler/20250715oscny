import sys
print(f"{sys.argv = }\n")

print("This code is in spam.py\n")

if __name__ == "__main__":
    print("""This code is in if __name__ == "__main__" of spam.py""")
