import sys
print(f"{sys.argv = }\n")

print("This code is in ham/__init__.py\n")

if __name__ == "__main__":
    print("""This code is in if __name__ == "__main__" of ham/__init__.py""")
